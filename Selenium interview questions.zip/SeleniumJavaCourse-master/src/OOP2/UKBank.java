package OOP2;

public interface UKBank {
	
	
	public void educationLoan();
	

}
