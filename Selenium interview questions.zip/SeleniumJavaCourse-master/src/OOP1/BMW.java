package OOP1;

public class BMW extends Car{
	
	
	//Method Overriding: when the same method is present in parent class as well as in child class with the same and same no. of parameters.
	public void start(){
		System.out.println("BMW--start");
	}
	
	
	public void theftSafety(){
		System.out.println("BMW--theftSafety");
	}
	
	
	
	
	
	
	

}
